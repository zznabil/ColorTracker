# GUI module initialization
